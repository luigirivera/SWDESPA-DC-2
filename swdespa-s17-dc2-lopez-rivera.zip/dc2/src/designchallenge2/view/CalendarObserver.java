package designchallenge2.view;

public interface CalendarObserver {
	public void update();
}
